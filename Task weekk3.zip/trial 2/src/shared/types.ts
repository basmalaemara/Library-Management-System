export enum BookStatus {
  AVAILABLE = "available",
  BORROWED = "borrowed",
  RESERVED = "reserved"
}

export enum MembershipType {
  REGULAR = "regular",
  PREMIUM = "premium",
  STUDENT = "student"
}
