export var BookStatus;
(function (BookStatus) {
    BookStatus["AVAILABLE"] = "available";
    BookStatus["BORROWED"] = "borrowed";
    BookStatus["RESERVED"] = "reserved";
})(BookStatus || (BookStatus = {}));
export var MembershipType;
(function (MembershipType) {
    MembershipType["REGULAR"] = "regular";
    MembershipType["PREMIUM"] = "premium";
    MembershipType["STUDENT"] = "student";
})(MembershipType || (MembershipType = {}));
