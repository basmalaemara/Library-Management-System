import { Book } from "../models/Book.js";
import { Member } from "../models/Member.js";
import { BookStatus, MembershipType } from "../shared/types.js";

export class Library {
  books: Book[] = [];
  members: Member[] = [];

  addBook(book: Book): void {
    this.books.push(book);
    this.reindexAll();
  }

  addMember(member: Member): void {
    this.members.push(member);
    this.reindexAll();
  }

  borrowBook(memberId: number, bookId: number): boolean {
    const book = this.books.find(b => b.id === bookId);
    const member = this.members.find(m => m.id === memberId);
    if (!book || !member || book.status !== BookStatus.AVAILABLE) return false;

    book.borrow(memberId);
    member.borrowBook(bookId);
    this.saveToStorage();
    return true;
  }

  returnBook(bookId: number): boolean {
    const book = this.books.find(b => b.id === bookId);
    if (!book || book.status !== BookStatus.BORROWED || book.borrowedBy === null) return false;

    const member = this.members.find(m => m.id === book.borrowedBy);
    book.return();
    member?.returnBook(bookId);
    this.saveToStorage();
    return true;
  }

  getBookById(bookId: number): Book | undefined {
    return this.books.find(b => b.id === bookId);
  }

  getMemberById(memberId: number): Member | undefined {
    return this.members.find(m => m.id === memberId);
  }

  getAllBooks(): Book[] {
    return this.books;
  }

  getAllMembers(): Member[] {
    return this.members;
  }

  deleteBook(bookId: number): string {
  const bookIndex = this.books.findIndex(b => b.id === bookId);
  const book = this.books[bookIndex];
  if (!book) return "not_found";

  if (book.status === BookStatus.BORROWED) {
    return "borrowed";
  }

  this.books.splice(bookIndex, 1);
  this.saveToStorage();
  this.reindexAll();
  return "deleted";
}

deleteMember(memberId: number): string {
  const memberIndex = this.members.findIndex(m => m.id === memberId);
  const member = this.members[memberIndex];
  if (!member) return "not_found";

  if (member.borrowedBooks.length > 0) {
    return "has_borrowed";
  }

  this.members.splice(memberIndex, 1);
  this.saveToStorage();
  this.reindexAll();
  return "deleted";
}


  reindexAll(): void {
    this.books.forEach((book, index) => {
      book.id = index + 1;
    });
    this.members.forEach((member, index) => {
      member.id = index + 1;
    });
    this.books.forEach(book => {
      if (book.borrowedBy !== null) {
        const member = this.members.find(m => m.borrowedBooks.includes(book.id));
        book.borrowedBy = member ? member.id : null;
      }
    });
    this.members.forEach(member => {
      member.borrowedBooks = member.borrowedBooks.filter(bookId =>
        this.books.some(b => b.id === bookId)
      );
    });

    this.saveToStorage();
  }

  saveToStorage(): void {
    localStorage.setItem("libraryBooks", JSON.stringify(this.books));
    localStorage.setItem("libraryMembers", JSON.stringify(this.members));
  }

  loadFromStorage(): void {
    const booksData = localStorage.getItem("libraryBooks");
    const membersData = localStorage.getItem("libraryMembers");

    this.books = booksData
      ? JSON.parse(booksData).map((b: any) => {
          const book = new Book(b.id, b.title, b.author);
          book.status = b.status as BookStatus;
          book.borrowedBy = b.borrowedBy;
          return book;
        })
      : [];

    this.members = membersData
      ? JSON.parse(membersData).map((m: any) => {
          const member = new Member(
            m.id,
            m.name,
            m.membershipType as MembershipType
          );
          member.borrowedBooks = m.borrowedBooks || [];
          return member;
        })
      : [];
  }
}
