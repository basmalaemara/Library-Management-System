import { Book } from "../models/Book.js";
import { Member } from "../models/Member.js";
import { BookStatus } from "../shared/types.js";
export class Library {
    constructor() {
        this.books = [];
        this.members = [];
    }
    addBook(book) {
        this.books.push(book);
        this.reindexAll();
    }
    addMember(member) {
        this.members.push(member);
        this.reindexAll();
    }
    borrowBook(memberId, bookId) {
        const book = this.books.find(b => b.id === bookId);
        const member = this.members.find(m => m.id === memberId);
        if (!book || !member || book.status !== BookStatus.AVAILABLE)
            return false;
        book.borrow(memberId);
        member.borrowBook(bookId);
        this.saveToStorage();
        return true;
    }
    returnBook(bookId) {
        const book = this.books.find(b => b.id === bookId);
        if (!book || book.status !== BookStatus.BORROWED || book.borrowedBy === null)
            return false;
        const member = this.members.find(m => m.id === book.borrowedBy);
        book.return();
        member?.returnBook(bookId);
        this.saveToStorage();
        return true;
    }
    getBookById(bookId) {
        return this.books.find(b => b.id === bookId);
    }
    getMemberById(memberId) {
        return this.members.find(m => m.id === memberId);
    }
    getAllBooks() {
        return this.books;
    }
    getAllMembers() {
        return this.members;
    }
    deleteBook(bookId) {
        const bookIndex = this.books.findIndex(b => b.id === bookId);
        const book = this.books[bookIndex];
        if (!book)
            return "not_found";
        if (book.status === BookStatus.BORROWED) {
            return "borrowed";
        }
        this.books.splice(bookIndex, 1);
        this.saveToStorage();
        this.reindexAll();
        return "deleted";
    }
    deleteMember(memberId) {
        const memberIndex = this.members.findIndex(m => m.id === memberId);
        const member = this.members[memberIndex];
        if (!member)
            return "not_found";
        if (member.borrowedBooks.length > 0) {
            return "has_borrowed";
        }
        this.members.splice(memberIndex, 1);
        this.saveToStorage();
        this.reindexAll();
        return "deleted";
    }
    reindexAll() {
        this.books.forEach((book, index) => {
            book.id = index + 1;
        });
        this.members.forEach((member, index) => {
            member.id = index + 1;
        });
        this.books.forEach(book => {
            if (book.borrowedBy !== null) {
                const member = this.members.find(m => m.borrowedBooks.includes(book.id));
                book.borrowedBy = member ? member.id : null;
            }
        });
        this.members.forEach(member => {
            member.borrowedBooks = member.borrowedBooks.filter(bookId => this.books.some(b => b.id === bookId));
        });
        this.saveToStorage();
    }
    saveToStorage() {
        localStorage.setItem("libraryBooks", JSON.stringify(this.books));
        localStorage.setItem("libraryMembers", JSON.stringify(this.members));
    }
    loadFromStorage() {
        const booksData = localStorage.getItem("libraryBooks");
        const membersData = localStorage.getItem("libraryMembers");
        this.books = booksData
            ? JSON.parse(booksData).map((b) => {
                const book = new Book(b.id, b.title, b.author);
                book.status = b.status;
                book.borrowedBy = b.borrowedBy;
                return book;
            })
            : [];
        this.members = membersData
            ? JSON.parse(membersData).map((m) => {
                const member = new Member(m.id, m.name, m.membershipType);
                member.borrowedBooks = m.borrowedBooks || [];
                return member;
            })
            : [];
    }
}
