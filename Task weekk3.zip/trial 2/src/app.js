import { Book } from "./models/Book.js";
import { Member } from "./models/Member.js";
import { Library } from "./services/Library.js";
document.addEventListener("DOMContentLoaded", () => {
    const library = new Library();
    library.loadFromStorage();
    const bookForm = document.getElementById("addBookForm");
    const memberForm = document.getElementById("addMemberForm");
    const bookList = document.getElementById("booksList");
    const memberList = document.getElementById("membersList");
    bookForm.addEventListener("submit", e => {
        e.preventDefault();
        const titleInput = document.getElementById("bookTitle");
        const authorInput = document.getElementById("bookAuthor");
        const title = titleInput.value.trim();
        const author = authorInput.value.trim();
        if (!title || !author) {
            showToast("Please enter both title and author.");
            return;
        }
        const duplicate = library.getAllBooks().some(b => b.title.toLowerCase() === title.toLowerCase() && b.author.toLowerCase() === author.toLowerCase());
        if (duplicate) {
            showToast("Book already exists.");
            return;
        }
        const book = new Book(0, title, author);
        library.addBook(book);
        showToast("Book added successfully!");
        renderBooks();
        bookForm.reset();
    });
    memberForm.addEventListener("submit", e => {
        e.preventDefault();
        const nameInput = document.getElementById("memberName");
        const typeInput = document.getElementById("membershipType");
        const name = nameInput.value.trim();
        const membershipType = typeInput.value;
        if (!name) {
            showToast("Please enter a name.");
            return;
        }
        const duplicate = library.getAllMembers().some(m => m.name.toLowerCase() === name.toLowerCase());
        if (duplicate) {
            showToast("Member already exists.");
            return;
        }
        const member = new Member(0, name, membershipType);
        library.addMember(member);
        showToast("Member added successfully!");
        renderMembers();
        memberForm.reset();
    });
    function renderBooks() {
        bookList.innerHTML = "";
        library.getAllBooks().forEach(book => {
            const li = document.createElement("li");
            const borrowed = book.borrowedBy !== null;
            const member = borrowed ? library.getMemberById(book.borrowedBy) : null;
            const borrowInfo = borrowed
                ? `<div class="borrow-info">Borrowed by Member: ${member?.name || "Unknown"}</div>`
                : "";
            const infoBtn = borrowed
                ? `<button data-id="${book.id}" class="info-btn info-colored">
            <i class="fa-solid fa-circle-info"></i> Info
          </button>`
                : "";
            const borrowBtn = `
        <button data-id="${book.id}" class="borrow-btn borrow-btn-colored"
          ${book.status !== "available" ? "disabled style='opacity: 0.5;'" : ""}>
          <i class="fa-solid fa-book-open-reader"></i> Borrow
        </button>`;
            const returnBtn = `
        <button data-id="${book.id}" class="return-btn return-btn-colored"
          ${book.status === "available" ? "disabled style='opacity: 0.5;'" : ""}>
          <i class="fa-solid fa-arrow-rotate-left"></i> Return
        </button>`;
            const deleteBtn = `
        <button data-id="${book.id}" class="delete-book-btn"
          ${borrowed ? "disabled style='opacity: 0.5;'" : ""}>
          <i class="fa-solid fa-trash"></i> Delete
        </button>`;
            const statusBtn = `
        <button class="status-indicator ${book.status === "available" ? "available" : "unavailable"}">
          ${book.status === "available" ? "Available" : "Unavailable"}
        </button>`;
            li.innerHTML = `
      <div>
        <strong>ID ${book.id}: ${book.title}</strong> by ${book.author}
        ${borrowInfo}
      </div>
      <div class="book-actions">
        ${infoBtn}
        ${borrowBtn}
        ${returnBtn}
        ${deleteBtn}
      </div>
      <div>
        ${statusBtn}
      </div>
    `;
            bookList.appendChild(li);
        });
        document.querySelectorAll(".info-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const info = btn.closest("li")?.querySelector(".borrow-info");
                if (info)
                    info.style.display = info.style.display === "none" ? "block" : "none";
            });
        });
        document.querySelectorAll(".borrow-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = +btn.dataset.id;
                const memberId = prompt("Enter Member ID to borrow:")?.trim();
                if (memberId) {
                    const success = library.borrowBook(+memberId, id);
                    showToast(success
                        ? "Book borrowed successfully!"
                        : "Borrow failed. Book may be unavailable or member ID is invalid.");
                    renderBooks();
                    renderMembers();
                }
            });
        });
        document.querySelectorAll(".return-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = +btn.dataset.id;
                const success = library.returnBook(id);
                showToast(success ? "Book returned successfully!" : "Return failed.");
                renderBooks();
                renderMembers();
            });
        });
        document.querySelectorAll(".delete-book-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = +btn.dataset.id;
                const result = library.deleteBook(id);
                if (result === "deleted") {
                    showToast("Book deleted successfully.");
                }
                else if (result === "borrowed") {
                    showToast("Cannot delete: Book is currently borrowed.");
                }
                else {
                    showToast("Book not found.");
                }
                renderBooks();
                renderMembers();
            });
        });
    }
    function renderMembers() {
        memberList.innerHTML = "";
        library.getAllMembers().forEach(member => {
            const borrowedTitles = member.borrowedBooks
                .map(bookId => library.getBookById(bookId)?.title)
                .filter((title) => !!title);
            const borrowedText = borrowedTitles.length
                ? borrowedTitles.join(", ")
                : "No books borrowed";
            const li = document.createElement("li");
            const hasBorrowed = member.borrowedBooks.length > 0;
            li.innerHTML = `
        <div>
          <strong>ID ${member.id}:</strong> ${member.name} (${member.membershipType})
          <div class="member-info" style="display: none; color: #444; font-size: 0.85rem; margin-top: 8px;">
            Borrowed Books: ${borrowedText}
          </div>
        </div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-top: 12px;">
          <button data-id="${member.id}" class="info-member-btn info-colored">
            <i class="fa-solid fa-circle-info"></i> Info
          </button>
          <button data-id="${member.id}" class="delete-member-btn" ${hasBorrowed ? "disabled style='opacity: 0.5;'" : ""}>
            <i class="fa-solid fa-trash"></i> Delete
          </button>
        </div>
      `;
            memberList.appendChild(li);
        });
        document.querySelectorAll(".info-member-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const info = btn.closest("li")?.querySelector(".member-info");
                if (info)
                    info.style.display = info.style.display === "none" ? "block" : "none";
            });
        });
        document.querySelectorAll(".delete-member-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = +btn.dataset.id;
                const result = library.deleteMember(id);
                if (result === "deleted") {
                    showToast("Member deleted successfully.");
                }
                else if (result === "borrowed") {
                    showToast("Cannot delete: Member still has borrowed books.");
                }
                else {
                    showToast("Member not found.");
                }
                renderMembers();
                renderBooks();
            });
        });
    }
    renderBooks();
    renderMembers();
});
function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}
