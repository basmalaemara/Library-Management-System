import { BookStatus } from "../shared/types.js";

export class Book {
  id: number;
  title: string;
  author: string;
  status: BookStatus;
  borrowedBy: number | null;

  constructor(id: number, title: string, author: string) {
    this.id = id;
    this.title = title;
    this.author = author;
    this.status = BookStatus.AVAILABLE;
    this.borrowedBy = null;
  }

  borrow(memberId: number): void {
    if (this.status === BookStatus.AVAILABLE) {
      this.status = BookStatus.BORROWED;
      this.borrowedBy = memberId;
    }
  }

  return(): void {
    this.status = BookStatus.AVAILABLE;
    this.borrowedBy = null;
  }
}
