import { BookStatus } from "../shared/types.js";
export class Book {
    constructor(id, title, author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.status = BookStatus.AVAILABLE;
        this.borrowedBy = null;
    }
    borrow(memberId) {
        if (this.status === BookStatus.AVAILABLE) {
            this.status = BookStatus.BORROWED;
            this.borrowedBy = memberId;
        }
    }
    return() {
        this.status = BookStatus.AVAILABLE;
        this.borrowedBy = null;
    }
}
