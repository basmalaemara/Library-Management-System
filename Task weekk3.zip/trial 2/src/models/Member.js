export class Member {
    constructor(id, name, membershipType) {
        this.borrowedBooks = [];
        this.id = id;
        this.name = name;
        this.membershipType = membershipType;
        this.borrowedBooks = [];
    }
    borrowBook(bookId) {
        this.borrowedBooks.push(bookId);
    }
    returnBook(bookId) {
        this.borrowedBooks = this.borrowedBooks.filter(id => id !== bookId);
    }
}
