import { MembershipType } from "../shared/types.js";

export class Member {
  id: number;
  name: string;
  membershipType: MembershipType;
  borrowedBooks: number[] = [];

  constructor(id: number, name: string, membershipType: MembershipType) {
    this.id = id;
    this.name = name;
    this.membershipType = membershipType;
    this.borrowedBooks = [];
  }

  borrowBook(bookId: number): void {
    this.borrowedBooks.push(bookId);
  }

  returnBook(bookId: number): void {
    this.borrowedBooks = this.borrowedBooks.filter(id => id !== bookId);
  }
}
