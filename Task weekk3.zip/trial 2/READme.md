# 📚 Library Management System

## Features

- Add books with title and author  
- Register members with name and membership type  
- Borrow and return books  
- Tracks book availability by not allowing borrow when the book is already borrowed  
- Prevents borrowing of unavailable books  
- When a book is borrowed, an info label shows which member borrowed it  
- The members list displays the IDs of all books borrowed by each member  

